# COMP3123 Lab Test 1

This project contains the solutions to the COMP3123 Lab Test 1, which includes tasks involving JavaScript (ES6) and Node.js. The tasks are structured as per the test 
requirements.

